if status is-interactive
    # 1. Execute your modular structural subsystems
    set_my_paths
    set_my_env
    set_my_aliases
    # 2. Conda Initialization Pipeline
    if test -f /home/al/miniconda3/bin/conda
        eval /home/al/miniconda3/bin/conda "shell.fish" "hook" $argv | source
    end

    if test -f "/home/al/miniconda3/etc/fish/conf.d/conda.fish"
        source "/home/al/miniconda3/etc/fish/conf.d/conda.fish"
    end

    # Activate your primary profile environment
    conda activate py

    # 3. PERMANENT GHOST RECOVERY OVERRIDE
    # This must remain down at the absolute bottom of config.fish to overwrite
    # Conda's dynamic runtime right-hand shell injections on shell launch:
    function fish_right_prompt
        # Keeps your right margin entirely blank without typing source manually!
    end
end

eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv fish)"
d
