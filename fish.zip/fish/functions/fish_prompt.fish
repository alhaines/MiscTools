function fish_prompt
    # Set crisp interface colors
    set -l conda_color cyan
    set -l time_color white
    set -l user_color brgreen
    set -l host_color brblue
    set -l path_color brcyan
    set -l end_char_color brgreen
    set -l shell_color brwhite

    # 1. Print the Conda virtual env on the LEFT side if active
    if set -q CONDA_DEFAULT_ENV
        printf "(%s%s%s)" (set_color $conda_color) "$CONDA_DEFAULT_ENV" (set_color normal)
    end

    # 2. Add the shell indicator block
    printf "(%sfish%s) " (set_color $shell_color) (set_color normal)

    # 3. Print the timestamp, user, host, and path metrics cleanly
    printf '%s%s %s%s@%s%s:%s%s' \
        (set_color $time_color) (date +%I:%M) \
        (set_color $user_color) $USER \
        (set_color $host_color) (prompt_hostname) \
        (set_color $path_color) (prompt_pwd)

    # 4. Print the final prompt termination hook without any right-side trailing leakage
    printf '%s> %s' (set_color $end_char_color) (set_color normal)
end

function fish_right_prompt
    # Hard-force the right margin to always remain entirely void of text lines
    true
end
