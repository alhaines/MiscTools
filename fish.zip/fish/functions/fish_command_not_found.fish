function fish_command_not_found
    set -l missing_cmd $argv[1]

    # ================================================================================================
    # ROUTINE A: THE CORE PATH RESOLUTION PROTECTION TRIGGER
    # ================================================================================================
    # Check if the missing string matches a file sitting in your dedicated project path
    set -l potential_py_path "/home/al/projects/py/$missing_cmd"

    if test -f "$potential_py_path"
        echo ""
        echo -e "\e[1;31m[Watchdog Intercepted Permission Block]\e[0m File '$missing_cmd' exists but lacks execution rights."
        echo -n "[Interactive Prompt] Grant execution permissions (chmod +x) and run? [y/n]: "

        # Capture keystroke entry point silently
        read -l -n 1 -P "" -s confirm_chmod
        echo (string lower $confirm_chmod)

        if test "$confirm_chmod" = "y" -o "$confirm_chmod" = "Y"
            echo -e "\e[1;32m[Executing]\e[0m chmod +x $potential_py_path"
            chmod +x "$potential_py_path"
            echo -e "\e[1;32m[Launching]\e[0m Invoking script context now:\n"

            # Grabs the rest of the arguments you typed beyond just the command word!
            eval "$potential_py_path $argv[2..-1]"
        else
            echo -e "\n\e[1;33m[Canceled]\e[0m Script remains locked."
        end
        return
    end

    # ================================================================================================
    # ROUTINE B: THE INDEXED RICH APT SELECTION SEARCH MATRIX
    # ================================================================================================
    echo -e "\n\e[1;31m[Intercepted Error]\e[0m Command '$missing_cmd' is missing from the environment."
    echo -e "\e[1;34m[Querying Cache]\e[0m Fetching strict package name matches for: $missing_cmd...\n"

    set -l matched_packages (sudo apt search $missing_cmd 2>/dev/null | python3 -c "
import sys
search_term = '$missing_cmd'.lower()
raw_input = sys.stdin.read().strip()
if not raw_input:
    sys.exit(1)
entries = raw_input.split('\n\n')
valid_packages = []
for entry in entries:
    lines = entry.strip().split('\n')
    if not lines or '/' not in lines[0]:
        continue
    app_name = lines[0].split('/')[0].strip()
    if search_term in app_name.lower():
        valid_packages.append(app_name)
if valid_packages:
    print(' '.join(valid_packages[:9]))
else:
    sys.exit(1)
")

    if test $status -ne 0; or test -z "$matched_packages"
        echo -e "\e[1;33m[Notice]\e[0m Omitted all entries. Zero hits found matching \"$missing_cmd\" inside package names."
        return
    end

    sudo apt search $missing_cmd 2>/dev/null | python3 -c "
import sys
from rich.console import Console
from rich.table import Table

search_term = '$missing_cmd'.lower()
console = Console()
entries = sys.stdin.read().strip().split('\n\n')

table = Table(title=f'Selectable Matches for: [bold cyan]{search_term}[/bold cyan]', show_header=True, header_style='bold magenta')
table.add_column('Key', style='bold yellow', justify='center')
table.add_column('Package Name', style='cyan')
table.add_column('Status/Architecture', style='green')
table.add_column('Description', style='white')

idx = 1
for entry in entries:
    lines = entry.strip().split('\n')
    if not lines or '/' not in lines[0]:
        continue
    app_name = lines[0].split('/')[0].strip()
    if search_term not in app_name.lower():
        continue
    parts = lines[0].split('/')
    meta_info = parts[1] if len(parts) > 1 else 'unknown'
    description = ' '.join([line.strip() for line in lines[1:]]) if len(lines) > 1 else ''
    table.add_row(str(idx), app_name, meta_info, description)
    idx += 1
    if idx > 9:
        break
console.print(table)
"

    echo -n "[Interactive Prompt] Enter Selection Number to Install, or press any other key to cancel: "
    read -l -n 1 -P "" -s target_selection
    echo "$target_selection"

    if string match -r '^[1-9]$' "$target_selection"; and test "$target_selection" -le (count $matched_packages)
        set -l chosen_package $matched_packages[$target_selection]
        echo -e "\n\e[1;32m[Executing]\e[0m Selection locked. Starting deployment of $chosen_package...\n"
        sudo apt install $chosen_package -y
    else
        echo -e "\n\e[1;33m[Canceled]\e[0m Selection cleared or aborted by user."
    end
end
