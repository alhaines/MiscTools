function sync_hp_S --description "Sync files modified today from system_files to server"
    find /home/al/system_files/ -type f -mmin -1440 -printf '%P\n' | rsync -av -e 'ssh -p 22' --files-from=- /home/al/system_files/ al@192.168.12.2:/home/al/system_files/
end
