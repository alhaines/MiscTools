function joy --wraps='bluetoothctl connect F8:31:6E:02:FD:58' --description 'alias joy=bluetoothctl connect F8:31:6E:02:FD:58'
  bluetoothctl connect F8:31:6E:02:FD:58 $argv
        
end
