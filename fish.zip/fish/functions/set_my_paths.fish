# FILE 1: /home/al/.config/fish/functions/set_my_paths.fish
function set_my_paths
    fish_add_path /home/al/projects
    fish_add_path /home/al/projects/txt
    fish_add_path /home/al/projects/py
    fish_add_path /home/al/projects/c
    fish_add_path /home/al/projects/scripts
    fish_add_path /home/al/projects/bin
    fish_add_path /home/al/projects/ruby
    fish_add_path /home/al/projects/.local/bin
    fish_add_path /home/al/projects/.cargo/bin
    fish_add_path /snap/bin
end
