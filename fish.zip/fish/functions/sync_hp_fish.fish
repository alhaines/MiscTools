function sync_hp_fish --description "Sync files modified today from fish config to server"
    find /home/al/.config/fish/ -type f -mmin -1440 -printf '%P\n' | rsync -av -e 'ssh -p 23' --files-from=- al@hp15:/home/al/.config/fish/ /home/al/.config/fish/
end

