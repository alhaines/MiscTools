function fish_postexec_handler --on-event fish_postexec
    # Capture the exit code of the job that just completed
    set -l last_status $status
    set -l full_command $argv[1]

    # Check if the command line explicitly targeted a Python context and failed
    if test $last_status -ne 0; and string match -q "python*" "$full_command"
        echo -e "\n\e[1;33m[Watchdog Alert]\e[0m Python script failed with status $last_status!"
        echo "Triggering your custom py_fix recovery engine..."
        
        # Call your custom script or function
        py_fix $full_command
    end
end
