function tellhp15 --description 'Send a notification to the HP15 host'
    # Define the title and message from arguments
    set -l title $argv[1]
    set -l message $argv[2]

    # If no message provided, use a default
    if not set -q argv[2]
        set message "Task Complete"
    end

    # The SSH command targeting HP15's display and bus
    # Replace 192.168.1.xxx with your actual HP15 IP
    ssh al@hp15 "DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus notify-send '$title' '$message'"
end
