function mnt -d "Mount or unmount alsdesk shares"
    set -l action "$argv[1]"

    set -l OS (uname)
    set -l MACHINE (uname -m)

    # Get system arch, stripping out extra -gnu on Linux
    set -l ARCH (perl -MConfig -le 'print $Config{archname}' | sed 's/gnu-//' | sed 's/^i[3456]86-/i386-/' | sed 's/armv5tejl/arm/')

    set -l alsdesk '192.168.12.2'
    set -l port 23

    switch "$action"
        case start
            if ping -c 1 "$alsdesk" &>/dev/null
                # Fileserver is up
                sshfs -o allow_other,IdentityFile=/home/al/.ssh/id_rsa,default_permissions,uid=1000,gid=1000,port=$port al@192.168.12.2:/home/al/system_files /home/al/system_files_A
                sshfs -o allow_other,IdentityFile=/home/al/.ssh/id_rsa,default_permissions,uid=1000,gid=1000,port=$port al@192.168.12.2:/home/al/ /home/al/alsdesk
                echo "Fileserver is up .. done mounting `alsdesk` shares.."
            else
                # Fileserver is down
                echo "Fileserver is not responding to ping."
            end

        case stop
            echo "Unmounting fileserver shares..."
            sudo umount /home/al/alsdesk
            sudo umount /home/al/system_files_A
            echo "Fileserver is down."

        case restart
            echo "Unmounting fileserver shares..."
            sudo umount /home/al/alsdesk
            sudo umount /home/al/system_files_A
            echo "Fileserver is down."

            if ping -c 1 "$alsdesk" &>/dev/null
                # Fileserver is up
                sshfs -o allow_other,IdentityFile=/home/al/.ssh/id_rsa,default_permissions,uid=1000,gid=1000,port=$port al@192.168.12.2:/home/al/system_files /home/al/system_files_A
                sshfs -o allow_other,IdentityFile=/home/al/.ssh/id_rsa,default_permissions,uid=1000,gid=1000,port=$port al@192.168.12.2:/home/al/ /home/al/alsdesk
                echo "Fileserver is up .. done mounting `alsdesk` shares.."
            else
                # Fileserver is down
                echo "Fileserver is not responding to ping."
            end

        case '*'
            echo "Usage: mnt start|stop|restart" >&2
            return 3
    end

    echo "$ARCH $OS $MACHINE"
end
