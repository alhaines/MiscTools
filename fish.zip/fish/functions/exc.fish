function exc --description "Unified Expert Help System, Script Execution and Database Explorer Dashboard"
    if test (count $argv) -lt 1
        echo -e "\e[1;33m[Usage]\e[0m Missing command token or flag option choice."
        echo "Usage:"
        echo "  exc <command>                 - Query Gemini & cht.sh for command use & save cheat sheet"
        echo "  exc -lc                       - List all cached Cheat Sheets in MySQL"
        echo "  exc -ff                       - List all synchronized Fish Functions in MySQL"
        echo "  exc -sc <keyword>             - Search cheat sheets contents for a term"
        echo "  exc -view <function_name>     - View saved source code of a function"
        return 1
    end

    set -l first_arg $argv[1]

    # Resolve aliases if the first argument matches one AND isn't a flag option
    if not string match -q -- "-*" "$first_arg"
        if type -q -- "$first_arg"
            set -l alias_def (alias | grep -w "alias $first_arg" | string split -m 1 "=" | tail -n 1 | string trim -c "'")
            if test -n "$alias_def"
                echo -e "\e[1;33m[Alias Expanded]\e[0m '$first_arg' -> '$alias_def'"
                # Set first_arg to the actual command (first word of alias definition)
                set first_arg (string split " " "$alias_def")[1]
            end
        end
    end

    switch $first_arg
        # --------------------------------------------------------------------------------------------
        # OPTION 1: LIST CACHED CHEAT SHEETS (-lc)
        # --------------------------------------------------------------------------------------------
        case '-lc'
            python3 -c "
import sys
sys.path.append('/home/al/system_files/projects/py')
import pymysql
from rich.console import Console
from rich.table import Table
from rich import box
try:
    import config
    conn = pymysql.connect(host='localhost', user='al', password=getattr(config, 'DB_PASSWORD', ''), database='als', charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
    with conn.cursor() as cursor:
        cursor.execute('SELECT id, command_name, updated_at FROM cheat_sheets ORDER BY command_name ASC')
        rows = cursor.fetchall()

    console = Console()
    table = Table(title='[bold magenta]Available Cheat Sheets (MySQL Cache)[/bold magenta]', show_header=True, header_style='bold cyan', box=box.ROUNDED)
    table.add_column('ID Key (AI)', style='yellow', justify='center')
    table.add_column('Command Utility Name', style='green')
    table.add_column('Last Database Sync Tracking Stamp', style='white')

    for r in rows:
        table.add_row(str(r['id']), r['command_name'], str(r['updated_at']))
    console.print('\n', table, '\n')
    conn.close()
except Exception as e:
    print(f'[Database Connection Error]: {e}')
"
            return 0

        # --------------------------------------------------------------------------------------------
        # OPTION 2: LIST FISH FUNCTIONS (-ff)
        # --------------------------------------------------------------------------------------------
        case '-ff'
            python3 -c "
import sys
sys.path.append('/home/al/system_files/projects/py')
import pymysql
from rich.console import Console
from rich.table import Table
from rich import box
try:
    import config
    conn = pymysql.connect(host='localhost', user='al', password=getattr(config, 'DB_PASSWORD', ''), database='als', charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
    with conn.cursor() as cursor:
        cursor.execute('SELECT id, function_name, updated_at FROM fish_functions ORDER BY function_name ASC')
        rows = cursor.fetchall()

    console = Console()
    table = Table(title='[bold magenta]Synchronized Fish Environment Functions[/bold magenta]', show_header=True, header_style='bold cyan', box=box.ROUNDED)
    table.add_column('ID Key (AI)', style='yellow', justify='center')
    table.add_column('Function Target Identifier', style='green')
    table.add_column('Last Modified Verification Stamp', style='white')

    for r in rows:
        table.add_row(str(r['id']), r['function_name'], str(r['updated_at']))
    console.print('\n', table, '\n')
    conn.close()
except Exception as e:
    print(f'[Database Connection Error]: {e}')
"
            return 0

        # --------------------------------------------------------------------------------------------
        # OPTION 3: SEARCH CHEAT SHEETS CONTENT (-sc <keyword>)
        # --------------------------------------------------------------------------------------------
        case '-sc'
            if test (count $argv) -lt 2
                echo -e "\e[1;31m[Error]\e[0m Please provide a search phrase match keyword."
                return 1
            end
            set -l search_term $argv[2]
            python3 -c "
import sys
sys.path.append('/home/al/system_files/projects/py')
import pymysql
from rich.console import Console
from rich.table import Table
from rich import box
try:
    import config
    conn = pymysql.connect(host='localhost', user='al', password=getattr(config, 'DB_PASSWORD', ''), database='als', charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
    with conn.cursor() as cursor:
        cursor.execute('SELECT id, command_name, sheet_content FROM cheat_sheets WHERE sheet_content LIKE %s', ('%' + sys.argv[1] + '%',))
        rows = cursor.fetchall()

    console = Console()
    table = Table(title=f'[bold yellow]Content Search Matches for: \"{sys.argv[1]}\"[/bold yellow]', show_header=True, header_style='bold magenta', box=box.ROUNDED)
    table.add_column('ID', style='yellow')
    table.add_column('Command Target', style='cyan')
    table.add_column('Matching Command Lines Found', style='white')

    for r in rows:
        matching_lines = [line.strip() for line in r['sheet_content'].splitlines() if sys.argv[1].lower() in line.lower()]
        summary = ' | '.join(matching_lines)[:80] + '...' if matching_lines else 'Matched in core body'
        table.add_row(str(r['id']), r['command_name'], summary)
    console.print('\n', table, '\n')
    conn.close()
except Exception as e:
    print(f'[Database Connection Error]: {e}')
" "$search_term"
            return 0

        # --------------------------------------------------------------------------------------------
        # OPTION 4: INSPECT/VIEW STORED SOURCE FUNCTION VALUE (-view <name>)
        # --------------------------------------------------------------------------------------------
        case '-view'
            if test (count $argv) -lt 2
                echo -e "\e[1;31m[Error]\e[0m Please specify a target function name."
                return 1
            end
            set -l view_target $argv[2]
            python3 -c "
import sys
sys.path.append('/home/al/system_files/projects/py')
import pymysql
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
try:
    import config
    conn = pymysql.connect(host='localhost', user='al', password=getattr(config, 'DB_PASSWORD', ''), database='als', charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
    with conn.cursor() as cursor:
        cursor.execute('SELECT function_source FROM fish_functions WHERE function_name = %s', (sys.argv[1],))
        row = cursor.fetchone()

    console = Console()
    if row:
        syntax_highlighted = Syntax(row['function_source'], 'fish', theme='monokai', line_numbers=True)
        panel = Panel(syntax_highlighted, title=f'[bold green] Stored Source View: {sys.argv[1]}.fish [/bold green]', border_style='magenta', padding=(1, 2))
        console.print('\n', panel, '\n')
    else:
        print(f'\033[1;31m[Error]\033[0m Function \"{sys.argv[1]}\" not found inside MySQL tables.')
    conn.close()
except Exception as e:
    print(f'[Database Connection Error]: {e}')
" "$view_target"
            return 0

        # --------------------------------------------------------------------------------------------
        # PROJECT SCRIPT PASS-THROUGH AND ROOT PRIVILEGE INTERCEPT INTERACTIVE AUTO-TRAP LAYER
        # --------------------------------------------------------------------------------------------
        case '*'
            if string match -q "*.py" $first_arg; or test -f "/home/al/system_files/projects/py/$first_arg"; or test -f "$first_arg"
                set -l target_script "$first_arg"
                if not test -f "$target_script"; and test -f "/home/al/system_files/projects/py/$target_script"
                    set target_script "/home/al/system_files/projects/py/$target_script"
                end

                # Run script execution internally and capture its output streams to trap permission exits
                set -l script_output (/home/al/miniconda3/envs/py/bin/python3 $target_script $argv[2..-1] 2>&1)

                if string match -qi "*must be run as root*" "$script_output"; or string match -qi "*root privilege*" "$script_output"; or string match -qi "*run as sudo*" "$script_output"; or string match -qi "*permission denied*" "$script_output"
                    echo -e "\n\e[1;33m[Root Permission Match Detected]\e[0m Output says: \"$script_output\""
                    read -l -P "Do you wish to execute using sudo? [y/N]: " confirm_sudo
                    if string match -qi "y" "$confirm_sudo" or string match -qi "yes" "$confirm_sudo"
                        echo -e "\e[1;32m[Escalating Privileges]\e[0m Re-routing execution via sudo..."
                        sudo /home/al/miniconda3/envs/py/bin/python3 $target_script $argv[2..-1]
                    else
                        echo -e "\e[1;31m[Cancelled]\e[0m Execution halted by user request."
                    end
                else
                    # If normal output lines exist without error indicators, output clean text strings
                    echo -e "$script_output"
                end
                return 0
            end

            # Baseline Passthrough AI Query Pipeline Mode
            set -l search_word $first_arg
            set -l distro_name "Linux"
            if test -f /etc/os-release
                set -l raw_pretty (cat /etc/os-release | grep "PRETTY_NAME=" | string replace 'PRETTY_NAME=' '' | string replace -a '"' '' | string replace -a "'" '')
                set distro_name (string replace -i " OS" "" $raw_pretty | string replace -a " " "")
            end

            set -l target_prompt "briefly explain example uses of $search_word on $distro_name exclude install info"
            echo -e "\e[1;34m[Query Initiated]\e[0m Command: \e[1;36m$search_word\e[0m | Target Distro: \e[1;35m$distro_name\e[0m"

            /home/al/miniconda3/envs/py/bin/python3 /home/al/system_files/projects/py/ai_search.py ask "$target_prompt" 2>&1 | python3 -c "
import sys, os, subprocess, pymysql
sys.path.append('/home/al/system_files/projects/py')
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

try:
    console = Console()
    raw_output = sys.stdin.read()
    search_word = sys.argv[1]
    distro_name = sys.argv[2]

    if '503' in raw_output or 'UNAVAILABLE' in raw_output or 'high demand' in raw_output:
        print('\n\033[1;33m[API Spike Detected]\033[0m Gemini is busy. Please try again in a moment.')
        sys.exit(0)

    # 1. Output the Gemini AI Markdown Panel Analysis
    if '--- Gemini Response ---' in raw_output:
        content = raw_output.split('--- Gemini Response ---')[1].split('-----------------------')[0]
        markdown_payload = content.strip()
        if markdown_payload:
            console.print('\n')
            console.print(Panel(Markdown(markdown_payload), title=f'[bold magenta] Command Analysis: {search_word} [/bold magenta]', subtitle=f'[bold cyan] {distro_name} Environment [/bold cyan]', border_style='green', padding=(1, 2)))
            console.print('\n')

    # 2. Fetch cht.sh cleanly (?T drops ANSI colors) and map into a Rich Table
    cht_data = ''
    try:
        cht_data = subprocess.check_output(['curl', '-s', f'cht.sh/{search_word}?T'], text=True)
    except Exception as e:
        print(f'[Error] Unable to reach cht.sh data for {search_word}: {e}')

    if cht_data:
        cmd_table = Table(title=f'cht.sh Command Playbook: {search_word}', show_header=True, header_style='bold cyan')
        cmd_table.add_column('Description Context', style='yellow', overflow='fold')
        cmd_table.add_column('Command Syntax', style='green')

        current_desc = []
        for line in cht_data.splitlines():
            s_line = line.strip()
            if not s_line:
                continue

            # Group comment lines as the description
            if s_line.startswith('#'):
                current_desc.append(s_line.lstrip('#').strip())
            else:
                # Add the command and its associated description to the table
                desc_text = ' '.join(current_desc) if current_desc else 'Example Usage'
                cmd_table.add_row(desc_text, s_line)
                current_desc = []

        # Print beautifully to the terminal
        console.print(cmd_table)
        console.print('\n')

        # 3. Save the actual table rendering structure to the file (without terminal color codes)
        dest_dir = '/home/al/system_files/txt'
        os.makedirs(dest_dir, exist_ok=True)
        dest_file = os.path.join(dest_dir, f'{search_word}_cheat_sheet.txt')

        with open(dest_file, 'w', encoding='utf-8') as f:
            file_console = Console(file=f, force_terminal=False, width=120)
            file_console.print(cmd_table)

        print(f'\033[1;32m[Saved Cheat Sheet]\033[0m Playbook table written out to: {dest_file}')
        os.system('/home/al/system_files/projects/py/update_functions.py > /dev/null 2>&1')
    else:
        print(f'\033[1;33m[Notice]\033[0m No detailed examples found on cht.sh for {search_word}.')

except Exception as e:
    print(f'[Error Logging Pipeline]: {e}')
" "$search_word" "$distro_name"
    end
end
