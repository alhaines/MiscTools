function tell --description 'Send a notification to the host'
    # Define the title and message from arguments
    set -l host $argv[1]
    set -l title $argv[2]
    set -l message $argv[3]

    # If no message provided, use a default
    if not set -q argv[3]
        set message "Task Complete"
    end

    # The SSH command
    # Replace 192.168.12.2 with your actual HP15 IP
    if $host eq 'alsdesk'
        ssh -p 23 al@$host "DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus notify-send '$title' '$message'"
        set message "Task Complete"
     else
         ssh al@$host "DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus notify-send '$title' '$message'"
    end

end
