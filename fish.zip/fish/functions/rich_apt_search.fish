function rich_apt_search
    set -l search_word $argv[1]
    
    if test -z "$search_word"
        echo -e "\e[1;31m[Error]\e[0m Please provide a search query. Usage: rich_apt_search <keyword>"
        return 1
    end

    echo -e "\e[1;34m[Querying Cache]\e[0m Fetching matching apt packages for: $search_word...\n"

    # Pipe the raw output from apt search into Python to parse paths and format the final Rich layout table
    sudo apt search $search_word 2>/dev/null | python3 -c "
import sys, re
from rich.console import Console
from rich.table import Table

search_term = '$search_word'.lower()
console = Console()

# Initialize the UI component matrix layout
table = Table(title=f'Strict Match Results for: [bold cyan]{search_term}[/bold cyan]', show_header=True, header_style='bold magenta')
table.add_column('Package Name', style='cyan', no_wrap=True)
table.add_column('Status/Architecture', style='green')
table.add_column('Description', style='white')

raw_input = sys.stdin.read().strip()
if not raw_input:
    console.print('[bold red]No data received from apt.[/bold red]')
    sys.exit(0)

# Apt outputs packages separated by a blank line or newline pairings
entries = raw_input.split('\n\n')
match_count = 0

for entry in entries:
    lines = entry.strip().split('\n')
    if not lines:
        continue
    
    # Line 1 contains the package name, architecture, and deployment status tags
    header_line = lines[0]
    
    # Split out the name metadata cleanly
    parts = header_line.split('/')
    if not parts:
        continue
        
    app_name = parts[0].strip()
    
    # STRICT FILTER RULE: Unusable if search_word isn't inside the literal app name string boundary
    if search_term not in app_name.lower():
        continue
        
    # Extract structural flags if present (e.g., [installed], amd64)
    meta_info = parts[1] if len(parts) > 1 else 'unknown'
    
    # Remaining lines constitute the text block description summary
    description = ' '.join([line.strip() for line in lines[1:]]) if len(lines) > 1 else 'No description available.'
    
    table.add_row(app_name, meta_info, description)
    match_count += 1

if match_count > 0:
    console.print(table)
else:
    console.print(f'[bold yellow]Omitted all entries. Zero hits found containing \"{search_term}\" strictly inside the app name layer.[/bold yellow]')
"
end
