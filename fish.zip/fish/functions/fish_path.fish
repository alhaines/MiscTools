# filename = alsdesk:system_files/projects/.fish_paths
# --- Paths ---
function fish_path
    # fish_path.fish
    fish_add_path ~/py
    fish_add_path ~/c
    fish_add_path ~/sbin
    fish_add_path ~/scripts
    fish_add_path ~/bin
    fish_add_path ~/ruby
    fish_add_path ~/.local/bin
    fish_add_path /snap/bin
    fish_add_path /snap/bin
end

