function fish_greeting
    # Keeps your shell launch silent and clean on login!
function py_fix
    echo "py_fix execution engine engaged for command line string: $argv"
    # Insert any recovery mechanics, log purges, or syntax validation here.
end
# automation triggers
function auto_watchdog --on-event fish_postexec
    set -l exit_code $status
    if test $exit_code -eq 130
        echo -e "\n\e[1;33m[Watchdog]\e[0m Process forcefully interrupted by user (Ctrl+C)."
    end
end
function bind_quick_status
    # Binds Alt+S to instantly print active background jobs and system memory metrics
    netstat -an | grep 8022
    jobs
end
function complete_environments
    # Returns a dynamic string array to the tab-completion engine
    proot-distro list | awk '{print $1}'
end
function check_core_daemons
    echo -e "\e[1;34m[System Discovery]\e[0m Auditing active port channels..."

    set -l ports 8022 5901
    set -l names "SSH Server" "TigerVNC Engine"

    for i in (seq (count $ports))
        if netstat -an | grep -q ".\*$ports[$i].\*LISTEN"
            echo -e "  \e[1;32m[ONLINE]\e[0m $names[$i] actively bound to port $ports[$i]"
        else
            echo -e "  \e[1;31m[OFFLINE]\e[0m $names[$i] on port $ports[$i] is inactive."
        end
    end
end
function force_display_target
    set -l target_display $argv[1]
    if test -z "$target_display"
        set target_display ":1" # Fall back to default local VNC display canvas
    end

    set -gx DISPLAY $target_display
    echo -e "\e[1;32m[Display Target Set]\e[0m All graphical applications routed to $DISPLAY"
end

end
