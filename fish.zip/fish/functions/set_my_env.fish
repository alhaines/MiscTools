# FILE 2: /home/al/.config/fish/functions/set_my_env.fish
function set_my_env
    set -gx LC_ALL en_US.UTF-8
    set -gx LANG en_US.UTF-8
    set -gx PAGER less
    set -gx PA qazxcvbnm
    set -gx SUDO_ASKPASS /home/al/scripts/askpass.sh
    set -gx CONDA_CHANGEPS1 no
    set -g fish_history_max 10000
    set -g fish_history_ignore_dups yes
    set -g OS=`uname`
    set -g MACHINE=`uname -m`
    # get system arch, stripping out extra -gnu on Linux
    set -g ARCH=`/usr/bin/perl -MConfig -le 'print $Config{archname}' | sed 's/gnu-//' | sed 's/^i[3456]86-/i386-/' | sed 's/armv5tejl/arm/' `
end
