function get_yt_transcript --description "Downloads and cleans the auto-generated English YouTube transcript using saved cookies."
    # Check if a URL was provided
    if test (count $argv) -ne 1
        echo "Usage: get_yt_transcript <YouTube_URL>"
        return 1
    end

    set url $argv[1]
    # Check for your cookies file
    set cookies_file "~/youtube_cookies.txt"
    
    if ! test -f $cookies_file
        echo "❌ ERROR: Cookies file not found at $cookies_file. Please run Step 1 & 2."
        return 1
    end
    
    set temp_srt_file "/tmp/yt_transcript_(date +%s).srt"
    set output_file "transcript_for_geany.txt"

    echo "Attempting to download transcript using authenticated session..."

    # Step 1: Download the auto-generated SRT file using cookies
    # Added --cookies $cookies_file
    yt-dlp \
        --skip-download \
        --write-auto-subs \
        --sub-langs en \
        --convert-subs srt \
        --cookies $cookies_file \
        -o $temp_srt_file $url 2>&1 | grep -v "Writing video subtitles to:"

    if test -f $temp_srt_file
        echo "Transcript downloaded to temporary file. Cleaning and formatting..."
        
        # Step 2: Use awk to clean the SRT file
        awk '{ if ($0 ~ /^[a-zA-Z0-9]/ && $0 !~ /^[0-9]+$/ && $0 !~ /-->/) print $0 }' $temp_srt_file > $output_file

        # Step 3: Remove the messy temporary SRT file
        rm $temp_srt_file
        
        echo "✅ Success! Clean text saved to $output_file"
    else
        echo "❌ ERROR: Could not download the transcript. Authentication may have expired."
    end
end
