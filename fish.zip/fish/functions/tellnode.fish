function tellnode --description 'Send a notification to the node'
    # usage :  tellhp15 hp15 "xxxxxxxxxxxxxxx" "1234567890"
    # Define the title and message from arguments
    set -l node $argv[1]
    set -l title $argv[2]
    set -l message $argv[3]

    # If no message provided, use a default
    if not set -q argv[2]
        set message "Task Complete"
    end

    # The SSH command targeting the node's display and bus
    if test "$node" = "alsdesk"
        # Port 23 for alsdesk
        ssh -p 23 -o StrictHostKeyChecking=no $USER@$node "DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus notify-send '$title' '$message'"
    else
        # Standard port for others nodes
        ssh -o StrictHostKeyChecking=no $USER@$node "DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus notify-send '$title' '$message'"
    end

end
